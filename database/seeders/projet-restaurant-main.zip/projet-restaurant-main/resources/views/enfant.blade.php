@extends('parent')

@section('header', 'my-header')

@section('content')
@parent
foo bar baz
@endsection
