@yield('header')

@section('content')
lorem ipsum
@show
