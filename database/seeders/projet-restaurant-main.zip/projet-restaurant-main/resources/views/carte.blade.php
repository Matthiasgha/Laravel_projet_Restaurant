@extends('base')

@section('content')
<h1>Carte</h1>

<h2>Entrées</h2>

<h2>Plats</h2>

<h2>Desserts</h2>

<h2>Boissons</h2>

@endsection