# Restaurant

## Données de test

https://mockaroo.com

```
if this == true then 'M.'
else 'Mme'
end
```

## Mentions légales

<a href="https://www.flaticon.com/free-icons/restaurant" title="restaurant icons">Restaurant icons created by Freepik - Flaticon</a>
